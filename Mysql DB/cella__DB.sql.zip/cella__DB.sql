-- phpMyAdmin SQL Dump
-- version 2.11.6
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jun 19, 2015 at 01:32 PM
-- Server version: 5.0.51
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `cella`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_login`
--

CREATE TABLE `admin_login` (
  `admin_id` int(11) NOT NULL auto_increment,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `level` tinyint(4) NOT NULL,
  PRIMARY KEY  (`admin_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `admin_login`
--

INSERT INTO `admin_login` (`admin_id`, `username`, `password`, `email`, `level`) VALUES
(1, 'cellagold', 'cella123', 'mindnotion@gmail.com', 1),
(2, 'cellasilver', 'cella123', 'mindnotion@gmail.com', 0);

-- --------------------------------------------------------

--
-- Table structure for table `order`
--

CREATE TABLE `order` (
  `order_id` bigint(20) NOT NULL auto_increment,
  `order_code` int(11) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `order_date` date NOT NULL,
  `total_price` decimal(10,0) NOT NULL,
  `total_discount` int(11) NOT NULL,
  `total_quantity` int(11) NOT NULL,
  `order_delivery_status` tinyint(4) NOT NULL,
  `order_delivery_date` date NOT NULL,
  `order_confirmation` tinyint(4) NOT NULL,
  PRIMARY KEY  (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `order`
--


-- --------------------------------------------------------

--
-- Table structure for table `order_product`
--

CREATE TABLE `order_product` (
  `order_id` bigint(20) NOT NULL,
  `order_code` int(11) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `product_id` bigint(20) NOT NULL,
  `product_code` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `price` decimal(10,0) NOT NULL,
  `discount_percent` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `size` varchar(255) NOT NULL,
  `dimension` varchar(255) NOT NULL,
  `isreturned` tinyint(4) NOT NULL,
  `order_return_date` date default NULL,
  `return_goods_condition` tinyint(4) default NULL,
  `return_reason` varchar(255) default NULL,
  `warehouse_entry_date` date default NULL,
  `is_cashback_approved` tinyint(4) default NULL,
  `is_cashback_returned` tinyint(4) default '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `order_product`
--


-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `product_id` bigint(20) NOT NULL auto_increment,
  `title` varchar(255) NOT NULL,
  `product_code` int(11) NOT NULL,
  `category` varchar(255) NOT NULL,
  `subcategory` varchar(255) default NULL,
  `color` varchar(255) NOT NULL,
  `price` decimal(10,0) NOT NULL,
  `discount_percent` int(11) default NULL,
  `new_arrival` tinyint(4) NOT NULL,
  `best_seller` tinyint(4) NOT NULL,
  `hit_count` int(11) NOT NULL,
  `gender` varchar(255) NOT NULL,
  PRIMARY KEY  (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `product`
--


-- --------------------------------------------------------

--
-- Table structure for table `product_brand`
--

CREATE TABLE `product_brand` (
  `id` bigint(20) NOT NULL auto_increment,
  `product_id` bigint(20) NOT NULL,
  `product_code` int(11) NOT NULL,
  `product_brand_title` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `product_brand`
--


-- --------------------------------------------------------

--
-- Table structure for table `product_desc_care`
--

CREATE TABLE `product_desc_care` (
  `id` bigint(20) NOT NULL auto_increment,
  `product_id` bigint(20) NOT NULL,
  `product_code` int(11) NOT NULL,
  `product_desc` text NOT NULL,
  `product_care` text NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `product_desc_care`
--


-- --------------------------------------------------------

--
-- Table structure for table `product_image`
--

CREATE TABLE `product_image` (
  `id` bigint(20) NOT NULL auto_increment,
  `product_id` bigint(20) NOT NULL,
  `product_code` int(11) NOT NULL,
  `image_path` varchar(255) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `product_image`
--


-- --------------------------------------------------------

--
-- Table structure for table `product_size_quantity`
--

CREATE TABLE `product_size_quantity` (
  `id` bigint(20) NOT NULL auto_increment,
  `product_id` bigint(20) NOT NULL,
  `product_code` int(11) NOT NULL,
  `size_type` varchar(255) default NULL,
  `dimension` varchar(255) default NULL,
  `quantity` int(11) NOT NULL,
  `availability` tinyint(4) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `product_size_quantity`
--


-- --------------------------------------------------------

--
-- Table structure for table `shipping`
--

CREATE TABLE `shipping` (
  `id` int(11) NOT NULL,
  `free_shipping_amt` varchar(255) NOT NULL,
  `shipping_amt` varchar(255) NOT NULL,
  `shipping_img_path` varchar(255) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `shipping`
--


-- --------------------------------------------------------

--
-- Table structure for table `user_cashback`
--

CREATE TABLE `user_cashback` (
  `user_id` bigint(20) NOT NULL,
  `product_id` bigint(20) NOT NULL,
  `product_code` int(11) NOT NULL,
  `order_id` bigint(20) NOT NULL,
  `order_return_date` date NOT NULL,
  `price` decimal(10,0) NOT NULL,
  `discount_percent` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `return_good_condition` tinyint(4) default NULL,
  `return_reason` varchar(255) default NULL,
  `warehouse_entry_date` date default NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_cashback`
--


-- --------------------------------------------------------

--
-- Table structure for table `user_details`
--

CREATE TABLE `user_details` (
  `user_id` bigint(20) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `telephone` bigint(19) NOT NULL,
  `shipping_address` text NOT NULL,
  `city` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `pincode` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_details`
--


-- --------------------------------------------------------

--
-- Table structure for table `user_login`
--

CREATE TABLE `user_login` (
  `user_id` bigint(20) NOT NULL auto_increment,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  PRIMARY KEY  (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `user_login`
--


-- --------------------------------------------------------

--
-- Table structure for table `user_referrals`
--

CREATE TABLE `user_referrals` (
  `user_id` bigint(20) NOT NULL,
  `referral_email` varchar(255) NOT NULL,
  `email_send_status` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_referrals`
--

